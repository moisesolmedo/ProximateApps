//
//  DBManager.h
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/14/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBManager : NSObject

@property (nonatomic, strong) NSMutableArray *arrColumnNames;

@property (nonatomic) int affectedRows;

@property (nonatomic) long long lastInsertedRowID;

-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename;

-(NSArray *)loadDataFromDB:(NSString *)query imageOrData:(NSString *)dataType withDataObject:(NSData *)dataObject;

-(void)executeQuery:(NSString *)query imageOrTextOp:(NSString *)dataType withDataObject:(NSData *)dataObject;

@end
