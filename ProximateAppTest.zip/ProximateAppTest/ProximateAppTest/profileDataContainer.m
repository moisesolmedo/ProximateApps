//
//  profileDataContainer.m
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/13/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import "profileDataContainer.h"

@implementation profileDataContainer

@end
