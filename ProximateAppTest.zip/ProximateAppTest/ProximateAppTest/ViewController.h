//
//  ViewController.h
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/9/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "APIWebService.h"

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *correo;
@property (strong, nonatomic) IBOutlet UITextField *password;


- (void )loginMail:(NSString *)mail       passwrd:(NSString *)contrasenia    completion:( void (^)(NSDictionary* correoPassword) )completion;


@end

