//
//  profileDataContainer.h
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/13/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface profileDataContainer : NSObject

@property (nonatomic,strong) NSString *apellidos;
@property (nonatomic,strong) NSString *nombres;
@property (nonatomic,strong) NSString *correo;
@property (nonatomic,strong) NSString *documentoIdentidad;
@property (nonatomic,strong) NSString *estatusUsuario;
@property (nonatomic,strong) NSString *numeroDocumento;
@property (nonatomic,strong) NSDictionary *secciones;

@property (nonatomic, strong) NSData *fotoPerfilData;
@property (nonatomic, strong) NSString *latitud;
@property (nonatomic, strong) NSString *longitud;



@end
