//
//  profileDetails.h
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/13/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "profileDataContainer.h"
#import <CoreLocation/CoreLocation.h>
#import "DBManager.h"


@interface profileDetails : UIViewController <CLLocationManagerDelegate> 
@property(nonatomic, strong) profileDataContainer *profDataContner;
@property (strong, nonatomic) IBOutlet UILabel *nombreLabel;
@property (strong, nonatomic) IBOutlet UILabel *apellidosLabel;
@property (strong, nonatomic) IBOutlet UILabel *correoLabel;
@property (strong, nonatomic) IBOutlet UILabel *documentoIdLabel;
@property (strong, nonatomic) IBOutlet UILabel *numeroIDLabel;
@property (strong, nonatomic) IBOutlet UILabel *estadoUsuarioLabel;
@property (strong, nonatomic) IBOutlet UILabel *seccionesLabel;
@property (strong, nonatomic) IBOutlet UIImageView *imageFromAlbum;
@property (strong, nonatomic) IBOutlet UILabel *latitudLabel;
@property (strong, nonatomic) IBOutlet UILabel *longitudeLabel;
@property (strong, nonatomic) IBOutlet UILabel *addressLabel;


@end
