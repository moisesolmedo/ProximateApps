//
//  ViewController.m
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/9/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import "ViewController.h"
#import "profileDetails.h"
#import "profileDataContainer.h"
#import "DBManager.h"

static NSString * const SCHEMEPROTOCOL = @"https://%@";
static NSString * const HOST = @"serveless.proximateapps-services.com.mx%@";
static NSString * const PATHTOLOGIN = @"/catalog/dev/webadmin/authentication/login";
static NSString * const PATHTOPROFILE = @"/catalog/dev/webadmin/users/getdatausersession";

@interface ViewController ()<UITextFieldDelegate>
{
    NSDictionary *tempDict;
    NSURLSessionDataTask *task;
    NSURLSession *session;
    int iden;
    NSData * nullData;
    NSString * alertActionTitle;
}
@property (nonatomic,strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UIAlertController *alert;
@property (nonatomic, strong) UIAlertAction* actionButton;
@property (nonatomic, strong) NSMutableString *successfulLogin;
@property (nonatomic, strong) NSMutableString *token_Authentication;
@property (nonatomic, strong) NSMutableString *messageHTTPResponseAuthentication;
@property(nonatomic, strong) profileDataContainer *pDc;
@property (nonatomic, strong) DBManager *dbManager;

@end

@implementation ViewController
@synthesize spinner;
@synthesize alert;
@synthesize actionButton;
@synthesize successfulLogin;
@synthesize token_Authentication;
@synthesize messageHTTPResponseAuthentication;

- (IBAction)Login:(id)sender {
    
    messageHTTPResponseAuthentication = [NSMutableString stringWithFormat:@"" ];
    successfulLogin = [NSMutableString stringWithFormat:@"" ];
    
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.center = CGPointMake([[UIScreen mainScreen] bounds].size.width/2, 200);
    spinner.tag = 12;
    [self.view addSubview:spinner];
    [spinner startAnimating];
    
    NSLog(@"+ Se ejecuta el botón loginButton");
    
    
    NSLog(@"         - 1C Inicio de la configuración del AlertController en loginMail");
    alert = [UIAlertController
             alertControllerWithTitle:@"Title"
             message: @"Message"
             preferredStyle:UIAlertControllerStyleAlert];
    

    [self loginMail:self.correo.text passwrd:self.password.text completion:^(NSDictionary *correoPassword)
     {
         NSLog(@"Se ejecuta el bloque de completion del método loginMail");
         tempDict = [NSDictionary dictionaryWithDictionary: correoPassword];
     }];
    
    NSLog(@"+ Fin del flujo de la ejecución de loginButton\n");
    
}





-(void)loginMail:(NSString *)mail passwrd:(NSString *)contrasenia completion:(void (^)(NSDictionary *))completion{
    
    //clear UITextFields
    self.correo.text=@"";
    self.password.text=@"";
    
    NSString *forgedURL = [NSString stringWithFormat: [NSString stringWithFormat:SCHEMEPROTOCOL, HOST], PATHTOLOGIN];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat: @"%@",forgedURL]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    NSDictionary *dataToSend = [NSDictionary dictionaryWithObjects:@[mail, contrasenia] forKeys:@[@"correo",@"contrasenia"]];
    
    NSError *error;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dataToSend options:0 error:&error];
    
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSData *requestData = [NSData dataWithBytes:[jsonString UTF8String] length:[jsonString lengthOfBytesUsingEncoding:NSUTF8StringEncoding]];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:@"application/json; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%lu", (unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody: requestData];
    
    
    session = [NSURLSession sharedSession];
    
    task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable Data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            return;
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSLog(@"Response HTTP Status Code: %ld\n", (long)[(NSHTTPURLResponse *)response statusCode]);
            NSLog(@"Response HTTP Headers: \n%@\n", [(NSHTTPURLResponse *)response allHeaderFields]);
            
        }
        
        NSString *body = [[NSString alloc] initWithData:Data encoding:NSUTF8StringEncoding];
        NSLog(@"Response Body: \n%@\n", body);
        
        NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:Data options:kNilOptions error:&error];
        NSLog(@"\n\nResponse responseDict: \n%@\n", responseDict);
        
        messageHTTPResponseAuthentication = responseDict[@"message"];
        if ([responseDict[@"success"] boolValue] )
        {
            alertActionTitle = @"Aceptar";
            alert.title = @"Login Correcto";
            alert.message = @"Acceso concedido";

            
            NSLog(@"Success = %@", responseDict[@"success"]);
            successfulLogin = [[NSMutableString alloc] initWithFormat:@"Autenticado"];
            token_Authentication = [[NSMutableString alloc] initWithFormat:@"%@", responseDict[@"token"]];
            
            iden=[responseDict[@"id"] intValue];
            
            
            // Prepare the query string.
            NSString *query = [NSString stringWithFormat:@"update autenticacion set token ='%@', id=%i", token_Authentication, iden];
            
            // Execute the query.
            [self.dbManager executeQuery:query imageOrTextOp:@"text" withDataObject:nullData];
            
            // If the query was successfully executed then pop the view controller.
            if (self.dbManager.affectedRows != 0) {
                NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
                
            }
            else{
                NSLog(@"Could not execute the query.");
            }
            
        
            //---------
            NSMutableURLRequest *requestX = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat: @"https://serveless.proximateapps-services.com.mx/catalog/dev/webadmin/users/getdatausersession"]]];
            
            NSLog(@"RequestX before POST method:\n %@", requestX);
            
            [requestX setHTTPMethod:@"POST"];
            [requestX setValue:@"application/json; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
            [requestX setValue:token_Authentication forHTTPHeaderField:@"Authorization"];
            
            NSLog(@"RequestX after%@", requestX);
    
            NSURLSession *dataUserSession = [NSURLSession sharedSession];
            
            NSURLSessionDataTask *dataTask = [dataUserSession dataTaskWithRequest:requestX
                                                                completionHandler:^(NSData *dataUser, NSURLResponse *responseUser, NSError *error) {
                                                                    if (error) {
                                                                        NSLog(@"%@", error);
                                                                    } else
                                                                    {
                                                                        NSHTTPURLResponse *httpResponseUser = (NSHTTPURLResponse *) responseUser;
                                                                        NSLog(@"Response from getDataUserSession: %@", httpResponseUser);
                                                                        NSDictionary *responseDict2 = [NSJSONSerialization JSONObjectWithData:dataUser options:kNilOptions error:&error];
                                                                        
                                                                        NSLog(@"---------\n%@", responseDict2); // aqu[i esta la info para los detalles
                                                                        
                                                                        NSArray *userSessionResponseArray = [responseDict2 objectForKey:@"data"];
                                                                        
                                                                        NSLog(@"Data in array element 0 \n\n%@",userSessionResponseArray[0]);
                                                                        
                                                                        for (NSDictionary * dictionaryInUserSessionResponseArray in userSessionResponseArray) {
                                                                            self.pDc = [profileDataContainer new];
                                                                            NSLog(@"dictionary content\n\n %@", dictionaryInUserSessionResponseArray);
                                                                            
                                                                            self.pDc.nombres = dictionaryInUserSessionResponseArray[@"nombres"];
                                                                            self.pDc.apellidos = dictionaryInUserSessionResponseArray[@"apellidos"];
                                                                            self.pDc.correo = dictionaryInUserSessionResponseArray[@"correo"];
                                                                            self.pDc.documentoIdentidad = dictionaryInUserSessionResponseArray[@"documentos_label"];
                                                                            self.pDc.numeroDocumento = dictionaryInUserSessionResponseArray[@"numero_documento"];
                                                                            
                                                                            self.pDc.secciones=[[dictionaryInUserSessionResponseArray valueForKeyPath:@"secciones"] valueForKeyPath:@"seccion"];
                                                                            
                                                                            self.pDc.estatusUsuario = [dictionaryInUserSessionResponseArray valueForKey:@"estados_usuarios_label"];
                                                                            
                                                                            iden = [[dictionaryInUserSessionResponseArray valueForKey:@"id"] intValue];
                                                                            
                                                                            NSLog(@"Secciones obtenidas: \n%@", self.pDc.secciones);
                                                                            
                                                                        }
                                                                        NSMutableString *seccionesStr= [[NSMutableString alloc] init];
                                                                        for (NSMutableString *seccDict in self.pDc.secciones) {
                                                                            [seccionesStr appendString:seccDict];
                                                                            [seccionesStr appendString:@"\n"];
                                                                        }
                                                                        
                                                                        // Prepare the query string.
                                                                        NSString *query = [NSString stringWithFormat:@"update perfil set id =%i, nombres='%@', apellidos='%@', correo='%@', numerodocumento ='%@', documentoslabel ='%@', estadosusuarioslabel ='%@', secciones='%@'", iden, self.pDc.nombres, self.pDc.apellidos,self.pDc.correo, self.pDc.numeroDocumento, self.pDc.documentoIdentidad, self.pDc.estatusUsuario, seccionesStr];
                                                                        
                                                                        // Execute the query.
                                                                        [self.dbManager executeQuery:query imageOrTextOp:@"text" withDataObject:nullData];
                                                                        
                                                                        // If the query was successfully executed then pop the view controller.
                                                                        if (self.dbManager.affectedRows != 0) {
                                                                            NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
                                                                        }
                                                                        else{
                                                                            NSLog(@"Could not execute the query.");
                                                                        }
                                                                        
                                                                        NSString *queryDataImage = [NSString stringWithFormat:@"select fotoPerfil from perfil where id= %d", iden];
                                                                        
                                                                        //loadDataFromDB returns an array
                                                                        NSArray *resultImage = [[NSArray alloc] initWithArray: [self.dbManager loadDataFromDB:queryDataImage imageOrData:@"image" withDataObject:nullData]];
                                                                        
                                                                        NSData *imageData = [NSData dataWithData:[[resultImage objectAtIndex:0] objectAtIndex:0]];
                                                                        
                                                                        self.pDc.fotoPerfilData = imageData;
                                                                        
                                                                        
                                                                        NSString *queryCoordinates = [NSString stringWithFormat:@"select fotoLatitud, fotoLongitud from perfil where id= %d", iden];
                                                                        
                                                                        NSArray *resultCoordinates = [[NSArray alloc] initWithArray: [self.dbManager loadDataFromDB:queryCoordinates imageOrData:@"text" withDataObject:nullData]];
                                                                        
                                                                        self.pDc.latitud = [[resultCoordinates objectAtIndex:0] objectAtIndex:0];
                                                                        self.pDc.longitud = [[resultCoordinates objectAtIndex:0] objectAtIndex:1];
                                                                        
                                                                        NSString *queryX = [NSString stringWithFormat:@"select * from perfil"];
                                                                        
                                                                        // Load the relevant data. ESTO ES SOLO COMO MONITOREO, QUITAR AL FINAL
                                                                        NSArray *results = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:queryX imageOrData:@"text" withDataObject:nullData]];
                                                                        
                                                                        // Set the loaded data to the textfields.
                                                                        NSLog(@"El contenido de la tabla es: \n%@", [results objectAtIndex:0]);
                                                                        
                                                                    }
                                                                }];
            [dataTask resume];

        }
        else{
            alert.message= @"Usuario/password erróneo";
            alert.title = @"Error al ingresar";
            alertActionTitle = @"Reintentar";
        }
        
        completion(responseDict);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            UIAlertAction* actionButton = [UIAlertAction
                                           actionWithTitle: alertActionTitle
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action) {
                                               [spinner stopAnimating];
                                               [spinner hidesWhenStopped];
                                               if ([successfulLogin isEqualToString:@"Autenticado"]) {
                                                   
                                                   successfulLogin = (NSMutableString *)@"";
                                                   
                                                   //segue
                                                   [self performSegueWithIdentifier:@"segueToUserProfile" sender:nil];
                                                   
                                               }
                                               else{
                                                   //retry
                                                   NSLog(@"Retry");
                                               }
                                               
                                           }];
            
            [alert addAction:actionButton];

            [self presentViewController:alert animated:YES completion: nil];
        });
        
        
    }];   //Fin del task
    
    
    [task resume];  // ahora quiero que se ejecute el
    

}



-(void)loadInfoToEdit{
    // Create the query.
    NSString *query = [NSString stringWithFormat:@"select * from autenticacion"];
    
    // Load the relevant data.
    NSArray *results = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:query imageOrData:@"text" withDataObject:nullData]];
    
    // Set the loaded data to the textfields.
   NSLog(@"El contenido de la tabla es: \n%@",  [[results objectAtIndex:0] objectAtIndex:[self.dbManager.arrColumnNames indexOfObject:@"token"]]);
    
}



- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"segueToUserProfile"])
    {
        profileDetails *pD = [segue destinationViewController];
        pD.profDataContner = self.pDc;
        
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{

    [self.correo resignFirstResponder];
    [self.password resignFirstResponder];
    return YES;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];

}



- (void)viewDidLoad {
    [super viewDidLoad];
 
    nullData = NULL;
    
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"userinfo.sqlite"];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
