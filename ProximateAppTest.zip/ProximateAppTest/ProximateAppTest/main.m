//
//  main.m
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/9/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
