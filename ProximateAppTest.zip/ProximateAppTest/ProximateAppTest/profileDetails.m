//
//  profileDetails.m
//  ProximateAppTest
//
//  Created by JUAN MOISÉS OLMEDO on 9/13/17.
//  Copyright © 2017 JUAN MOISÉS OLMEDO. All rights reserved.
//

#import "profileDetails.h"

@interface profileDetails ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{
    NSData* nullData;
}

@property (nonatomic, strong) DBManager *dbManager;
@property (nonatomic, strong) NSData* pngdata;

@end

@implementation profileDetails
{
    CLLocationManager *locationManager;
    CLGeocoder *geocoder;
    CLPlacemark *placemark;

}

@synthesize addressLabel;

- (IBAction)closeSessionBtn:(id)sender {
    
    UIImage *image = [UIImage imageNamed:@"blankProfilePicture.png"];
    NSData *imageDataPlaceHolder=UIImagePNGRepresentation(image);
    
    NSString *query = [NSString stringWithFormat:@"update perfil set fotoPerfil = ?"];
    
    // Execute the query.
    [self.dbManager executeQuery:query imageOrTextOp:@"image" withDataObject:imageDataPlaceHolder];
    
    // If the query was successfully executed then pop the view controller.
    if (self.dbManager.affectedRows != 0) {
        NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
        
    }
    else{
        NSLog(@"Could not execute the query.");
    }
   
    NSString *queryCoordinates = [NSString stringWithFormat:@"update perfil set id =%i, nombres='%@', apellidos='%@', correo='%@', numerodocumento ='%@', documentoslabel ='%@', estadosusuarioslabel ='%@', secciones='%@', fotoLatitud='%@', fotoLongitud='%@' ", -1, @"", @"", @"", @"",@"", @"",@"", @"", @""];
    
    // Execute the query.
    [self.dbManager executeQuery:queryCoordinates imageOrTextOp:@"text" withDataObject:nullData ];
    
    [self dismissViewControllerAnimated: YES completion: nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSMutableString *seccionesStr= [[NSMutableString alloc] init];
    locationManager = [[CLLocationManager alloc] init];
    geocoder = [[CLGeocoder alloc] init];
    nullData = NULL;
    
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"userinfo.sqlite"];
    self.nombreLabel.text = self.profDataContner.nombres;
    self.apellidosLabel.text = self.profDataContner.apellidos;
    self.correoLabel.text = self.profDataContner.correo;
    self.documentoIdLabel.text = self.profDataContner.documentoIdentidad;
    self.numeroIDLabel.text = self.profDataContner.numeroDocumento;
    self.imageFromAlbum.image =[UIImage imageWithData:self.profDataContner.fotoPerfilData];
    
    for (NSMutableString *seccDict in self.profDataContner.secciones) {
        [seccionesStr appendString:seccDict];
        [seccionesStr appendString:@"\n"];
    }
    self.seccionesLabel.text = seccionesStr;
    self.estadoUsuarioLabel.text = self.profDataContner.estatusUsuario;
    self.latitudLabel.text = self.profDataContner.latitud;
    self.longitudeLabel.text = self.profDataContner.longitud;
    
    locationManager = [[CLLocationManager alloc] init];
    [locationManager requestWhenInUseAuthorization];
    
    
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)takePhotoBtn:(id)sender {
    UIImagePickerController * imagePicker = [[UIImagePickerController alloc] init];
   // imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;     en Simulador no se puede usar
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    imagePicker.delegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil];
    
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {

    self.pngdata = UIImagePNGRepresentation ([info objectForKey:UIImagePickerControllerOriginalImage]); //PNG wrap
    UIImage* img = [UIImage imageWithData:self.pngdata];
    
    [locationManager requestLocation];
    
     NSString *query = [NSString stringWithFormat:@"update perfil set fotoPerfil = ?"];
    
    // Execute the query.
    [self.dbManager executeQuery:query imageOrTextOp:@"image" withDataObject:self.pngdata];
    
    // If the query was successfully executed then pop the view controller.
    if (self.dbManager.affectedRows != 0) {
        NSLog(@"Query was executed successfully. Affected rows = %d", self.dbManager.affectedRows);
    }
    else{
        NSLog(@"Could not execute the query.");
    }
    
    self.imageFromAlbum.image = img;
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    
    UIAlertController *errorAlert = [UIAlertController
             alertControllerWithTitle:@"Error al obtener ubicación"
             message: @"No fue posible obtener la ubicación actual"
             preferredStyle:UIAlertControllerStyleAlert];

    
    UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"Aceptar"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       
                                   }];
    [errorAlert addAction:okButton];
    [self presentViewController: errorAlert animated:YES completion:nil];

}

//- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
//{
//    NSLog(@"didUpdateToLocation: %@", newLocation);
//    CLLocation *currentLocation = newLocation;
//    
//    if (currentLocation != nil) {
//        self.latitudLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
//        self.longitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
//    }
//}

-(void) locationManager:(CLLocationManager *)manager didUpdateLocations:(nonnull NSArray<CLLocation *> *)locations{

    NSLog(@"Ubicacion %@",locations);
    if (locations != nil) {
        CLLocation *photoCurrentLocation = [locations objectAtIndex:0];
        
        self.latitudLabel.text = [NSString stringWithFormat:@"%.12f", photoCurrentLocation.coordinate.latitude];
        self.longitudeLabel.text = [NSString stringWithFormat:@"%.12f", photoCurrentLocation.coordinate.longitude];
        
        NSString *latitudStr = [NSString stringWithFormat:@"%f", photoCurrentLocation.coordinate.latitude];
        NSString *longitudStr = [NSString stringWithFormat:@"%f", photoCurrentLocation.coordinate.longitude];

        //------------------- Reverse Geocoding with Google APIs
        
        NSError *error = nil;
        
        NSString *lookUpString  = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&amp;sensor=false", photoCurrentLocation.coordinate.latitude,photoCurrentLocation.coordinate.longitude];
        
        lookUpString = [lookUpString stringByReplacingOccurrencesOfString:@" " withString:@"+"];
        
        NSData *jsonResponse = [NSData dataWithContentsOfURL:[NSURL URLWithString:lookUpString]];
        
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonResponse options:kNilOptions error:&error];
        
        NSArray* jsonResults = [jsonDict objectForKey:@"results"];
        
        
        NSLog(@"%@", jsonResults);
        
        //--------------------------------------------
        
        
        // Reverse Geocoding with CoreLocation Framework
        NSLog(@"Resolving the Address with CoreLocation");
        [geocoder reverseGeocodeLocation:photoCurrentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
            NSLog(@"Found placemarks: %@, error: %@", placemarks, error);
            if (error == nil && [placemarks count] > 0) {
                placemark = [placemarks lastObject];
                addressLabel.text = [NSString stringWithFormat:@"%@ %@\n%@ %@\n%@\n%@",
                                     placemark.subThoroughfare, placemark.thoroughfare,
                                     placemark.postalCode, placemark.locality,
                                     placemark.administrativeArea,
                                     placemark.country];
                NSString *addressStr = addressLabel.text;
                
                NSString *queryCoordinates = [NSString stringWithFormat:@"update perfil set fotoLatitud='%@', fotoLongitud='%@', geodecodedAddress='%@' ", latitudStr, longitudStr, addressStr];
                
                // Execute the query.
                [self.dbManager executeQuery:queryCoordinates imageOrTextOp:@"text" withDataObject:nullData ];
                
                NSLog(@"Latitud: %f", photoCurrentLocation.coordinate.latitude);
                NSLog(@"Longitud: %f", photoCurrentLocation.coordinate.longitude);
                
            } else {
                NSLog(@"%@", error.debugDescription);
            }
        } ];
        
    }
}


@end
